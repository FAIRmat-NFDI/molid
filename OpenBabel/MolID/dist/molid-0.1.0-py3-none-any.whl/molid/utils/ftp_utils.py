import ftplib

def get_total_files_from_ftp(ftp_server, ftp_directory):
    """Fetch the list of available files on the FTP server."""
    try:
        with ftplib.FTP(ftp_server) as ftp:
            ftp.login(user="anonymous", passwd="guest@example.com")
            ftp.cwd(ftp_directory)
            files = []
            ftp.retrlines("LIST", lambda x: files.append(x.split()[-1]))
            return [f for f in files if f.endswith(".sdf.gz")]
    except Exception as e:
        raise RuntimeError(f"Failed to fetch file list from FTP server: {e}")
