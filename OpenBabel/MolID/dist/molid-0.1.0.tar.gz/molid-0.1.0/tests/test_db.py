import unittest
import sqlite3
from molid.db.database import initialize_database, save_to_database

class TestDatabaseFunctions(unittest.TestCase):
    def test_initialize_and_save_to_database(self):
        fields = ["SMILES", "InChIKey"]
        database_file = "test.db"

        initialize_database(database_file, fields)

        conn = sqlite3.connect(database_file)
        cursor = conn.cursor()
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
        tables = [table[0] for table in cursor.fetchall()]
        self.assertIn("compound_data", tables)
        conn.close()
