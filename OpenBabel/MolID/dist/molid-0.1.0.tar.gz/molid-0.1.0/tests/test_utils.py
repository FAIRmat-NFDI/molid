import unittest
from pathlib import Path
from molid.pubchemproc.file_handler import validate_gz_file, unpack_gz_file, cleanup_files, move_file

class TestFileHandler(unittest.TestCase):

    def setUp(self):
        """Set up temporary files and folders for testing."""
        self.sample_gz_path = Path("test_sample.sdf.gz")
        self.sample_sdf_content = "Test content for unpacking."
        self.extracted_folder = Path("test_processed")
        self.destination_file = Path("test_moved.sdf")
        self.extracted_folder.mkdir(exist_ok=True)

        # Create a dummy .gz file for testing
        with gzip.open(self.sample_gz_path, "wb") as gz_file:
            gz_file.write(self.sample_sdf_content.encode())

    def tearDown(self):
        """Clean up temporary files and folders."""
        cleanup_files(self.sample_gz_path, self.extracted_folder, self.destination_file)

    def test_validate_gz_file(self):
        """Test validating a .gz file."""
        result = validate_gz_file(self.sample_gz_path)
        self.assertTrue(result)

    def test_unpack_gz_file(self):
        """Test unpacking a .gz file."""
        unpacked_file = unpack_gz_file(self.sample_gz_path, self.extracted_folder)
        self.assertTrue(unpacked_file.exists())
        self.assertEqual(unpacked_file.read_text(), self.sample_sdf_content)

    def test_cleanup_files(self):
        """Test cleaning up files."""
        file_to_delete = self.sample_gz_path
        cleanup_files(file_to_delete)
        self.assertFalse(file_to_delete.exists())

    def test_move_file(self):
        """Test moving a file."""
        unpacked_file = unpack_gz_file(self.sample_gz_path, self.extracted_folder)
        move_file(unpacked_file, self.destination_file)
        self.assertTrue(self.destination_file.exists())
        self.assertFalse(unpacked_file.exists())
