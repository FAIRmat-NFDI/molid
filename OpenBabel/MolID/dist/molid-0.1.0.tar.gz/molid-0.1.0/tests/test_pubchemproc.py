import unittest
from pathlib import Path
from molid.pubchemproc.pubchem import process_file
from molid.pubchemproc.file_handler import validate_gz_file, unpack_gz_file, cleanup_files

class TestPubChemProcessing(unittest.TestCase):

    def setUp(self):
        """Set up temporary files and folders for testing."""
        self.sample_gz_path = Path("test_sample.sdf.gz")
        self.extracted_folder = Path("test_processed")
        self.sample_sdf_path = self.extracted_folder / "test_sample.sdf"
        self.sample_sdf_content = """
        > <PUBCHEM_SMILES>
        CCO

        > <PUBCHEM_IUPAC_INCHIKEY>
        ZMXDDKWLCZADIW-UHFFFAOYSA-N

        $$$$
        """
        self.extracted_folder.mkdir(exist_ok=True)

        # Create a dummy .gz file for testing
        with gzip.open(self.sample_gz_path, "wb") as gz_file:
            gz_file.write(self.sample_sdf_content.encode())

    def tearDown(self):
        """Clean up temporary files and folders."""
        cleanup_files(self.sample_gz_path, self.extracted_folder)

    def test_validate_gz_file(self):
        """Test validating a .gz file."""
        result = validate_gz_file(self.sample_gz_path)
        self.assertTrue(result)

    def test_unpack_gz_file(self):
        """Test unpacking a .gz file."""
        unpacked_file = unpack_gz_file(self.sample_gz_path, self.extracted_folder)
        self.assertTrue(unpacked_file.exists())
        self.assertEqual(unpacked_file.read_text(), self.sample_sdf_content.strip())

    def test_process_file(self):
        """Test extracting data from an .sdf file."""
        # Ensure the .gz file is unpacked first
        unpack_gz_file(self.sample_gz_path, self.extracted_folder)
        result = process_file(self.sample_sdf_path, {"SMILES": "PUBCHEM_SMILES", "InChIKey": "PUBCHEM_IUPAC_INCHIKEY"})
        self.assertEqual(len(result), 1)
        self.assertEqual(result[0]["SMILES"], "CCO")
        self.assertEqual(result[0]["InChIKey"], "ZMXDDKWLCZADIW-UHFFFAOYSA-N")
